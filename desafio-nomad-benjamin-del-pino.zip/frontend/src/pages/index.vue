<template>
  <HomeView />
</template>

<script setup>
import HomeView from './HomeView.vue';

  //
</script>
